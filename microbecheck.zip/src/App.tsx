/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Search, History, Download, ChevronDown, ChevronUp, Loader2, Microscope, AlertCircle, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Markdown from "react-markdown";
import { fetchMicrobeData, MicrobeData } from "./services/geminiService";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const RECENT_SEARCHES_KEY = "microbecheck_recent_searches";

export default function App() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string |="" null="">(null);
  const [result, setResult] = useState<microbedata |="" null="">(null);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [expandedSections, setExpandedSections] = useState<record<string, boolean="">>({});
  const resultRef = useRef<htmldivelement>(null);

  useEffect(() => {
    const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  const saveSearch = (name: string) => {
    const updated = [name, ...recentSearches.filter(s => s !== name)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
  };

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const data = await fetchMicrobeData(searchQuery);
      setResult(data);
      saveSearch(data.name);
      // Expand first section by default
      if (data.sections.length > 0) {
        setExpandedSections({ [data.sections[0].title]: true });
      }
    } catch (err) {
      console.error(err);
      setError("Failed to fetch microbe data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const toggleSection = (title: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const exportToPDF = async () => {
    if (!result || !resultRef.current) return;
    
    const element = resultRef.current;
    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: "#0f172a",
      useCORS: true,
    });
    
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`MicrobeCheck_${result.name.replace(/\s+/g, "_")}.pdf`);
  };

  const clearRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem(RECENT_SEARCHES_KEY);
  };

  return (
    <div classname="min-h-screen bg-[#0f172a] text-slate-200 selection:bg-medical-teal/30">
      {/* Header */}
      <header classname="sticky top-0 z-50 bg-[#0f172a]/80 backdrop-blur-md border-b border-slate-800">
        <div classname="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div classname="flex items-center gap-2">
            <div classname="p-2 bg-medical-teal/10 rounded-lg">
              <microscope classname="w-6 h-6 text-medical-teal"/>
            </div>
            <h1 classname="text-xl font-bold tracking-tight text-white">
              Microbe<span classname="text-medical-teal">Check</span>
            </h1>
          </div>
          <div classname="text-xs font-mono text-slate-500 hidden sm:block">
            FRCPath Reference v1.0
          </div>
        </div>
      </header>

      <main classname="max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Search Section */}
        <section classname="space-y-4">
          <div classname="relative group">
            <input type="text" value="{query}" onchange="{(e)" ==""> setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch(query)}
              placeholder="Search organism (e.g. S. aureus, CMV, Aspergillus)..."
              className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-medical-teal/50 focus:border-medical-teal transition-all placeholder:text-slate-500 text-lg"
            />
            <search classname="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-medical-teal transition-colors"/>
            <button onclick="{()" ==""> handleSearch(query)}
              disabled={loading || !query.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-medical-teal hover:bg-medical-teal-dark disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-2 rounded-xl font-medium transition-all shadow-lg shadow-medical-teal/20"
            >
              {loading ? <loader2 classname="w-5 h-5 animate-spin"/> : "Search"}
            </button>
          </div>

          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <div classname="flex flex-wrap items-center gap-2 pt-2">
              <div classname="flex items-center gap-1 text-xs font-semibold text-slate-500 uppercase tracking-wider mr-2">
                <history classname="w-3 h-3"/>
                Recent
              </div>
              {recentSearches.map((s) => (
                <button key="{s}" onclick="{()" ==""> {
                    setQuery(s);
                    handleSearch(s);
                  }}
                  className="px-3 py-1 bg-slate-800/50 hover:bg-slate-700 border border-slate-700 rounded-full text-sm text-slate-300 transition-colors"
                >
                  {s}
                </button>
              ))}
              <button onclick="{clearRecent}" classname="p-1 text-slate-500 hover:text-red-400 transition-colors" title="Clear history">
                <trash2 classname="w-4 h-4"/>
              </button>
            </div>
          )}
        </section>

        {/* Error State */}
        <animatepresence>
          {error && (
            <motion.div initial="{{" opacity:="" 0,="" y:="" -10="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" exit="{{" opacity:="" 0,="" y:="" -10="" }}="" classname="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400">
              <alertcircle classname="w-5 h-5 shrink-0"/>
              <p classname="text-sm">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading State */}
        {loading && (
          <div classname="py-20 flex flex-col items-center justify-center space-y-4">
            <div classname="relative">
              <div classname="w-16 h-16 border-4 border-medical-teal/20 border-t-medical-teal rounded-full animate-spin"></div>
              <microscope classname="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-medical-teal"/>
            </div>
            <div classname="text-center">
              <p classname="text-lg font-medium text-white">Synthesizing Clinical Data...</p>
              <p classname="text-sm text-slate-500">Consulting UK SMIs, EUCAST & PubMed</p>
            </div>
          </div>
        )}

        {/* Results Section */}
        {result && !loading && (
          <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" classname="space-y-6">
            <div classname="flex items-end justify-between border-b border-slate-800 pb-4">
              <div>
                <div classname="flex items-center gap-2 mb-1">
                  <span classname="{cn(" "px-2="" py-0.5="" rounded="" text-[10px]="" font-bold="" uppercase="" tracking-widest",="" result.type="==" "bacteria"="" &&="" "bg-blue-500="" 20="" text-blue-400",="" result.type="==" "virus"="" &&="" "bg-purple-500="" 20="" text-purple-400",="" result.type="==" "fungus"="" &&="" "bg-orange-500="" 20="" text-orange-400",="" result.type="==" "parasite"="" &&="" "bg-green-500="" 20="" text-green-400"="" )}="">
                    {result.type}
                  </span>
                </div>
                <h2 classname="text-3xl font-bold text-white italic">{result.name}</h2>
              </div>
              <button onclick="{exportToPDF}" classname="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-sm font-medium transition-colors">
                <download classname="w-4 h-4"/>
                Export PDF
              </button>
            </div>

            <div ref="{resultRef}" classname="space-y-4 p-1">
              {/* Lifecycle Image for Parasites */}
              {result.imageUrl && (
                <div classname="bg-slate-900/40 border border-slate-800 rounded-2xl overflow-hidden p-4 space-y-3">
                  <div classname="flex items-center gap-2 text-xs font-semibold text-medical-teal uppercase tracking-wider">
                    <history classname="w-3 h-3"/>
                    Lifecycle Diagram (CDC DPDx)
                  </div>
                  <div classname="relative aspect-video bg-slate-800 rounded-xl overflow-hidden flex items-center justify-center">
                    <img src="{result.imageUrl}" alt="{result.imageCaption" ||="" "lifecycle="" diagram"}="" classname="max-w-full max-h-full object-contain" referrerpolicy="no-referrer"/>
                  </div>
                  {result.imageCaption && (
                    <p classname="text-xs text-slate-500 italic text-center">
                      {result.imageCaption}
                    </p>
                  )}
                </div>
              )}

              {result.sections.map((section) => (
                <div key="{section.title}" classname="bg-slate-900/40 border border-slate-800 rounded-2xl overflow-hidden">
                  <button onclick="{()" ==""> toggleSection(section.title)}
                    className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-800/50 transition-colors text-left"
                  >
                    <span classname="font-semibold text-slate-200">{section.title}</span>
                    {expandedSections[section.title] ? (
                      <chevronup classname="w-5 h-5 text-medical-teal"/>
                    ) : (
                      <chevrondown classname="w-5 h-5 text-slate-500"/>
                    )}
                  </button>
                  <animatepresence>
                    {expandedSections[section.title] && (
                      <motion.div initial="{{" height:="" 0,="" opacity:="" 0="" }}="" animate="{{" height:="" "auto",="" opacity:="" 1="" }}="" exit="{{" height:="" 0,="" opacity:="" 0="" }}="" transition="{{" duration:="" 0.2="" }}="">
                        <div classname="px-6 pb-6 pt-2 border-t border-slate-800/50">
                          <div classname="markdown-body text-sm text-slate-300">
                            <markdown>{section.content}</Markdown>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>

            <footer classname="pt-8 text-center text-xs text-slate-600 space-y-2">
              <p>© 2026 MicrobeCheck • FRCPath High-Yield Reference</p>
              <p>Data synthesized from UK SMIs, EUCAST, ClinMicroNow & Peer-reviewed literature.</p>
              <p classname="italic">Disclaimer: For educational purposes only. Always consult local trust guidelines for clinical decisions.</p>
            </footer>
          </motion.div>
        )}

        {/* Empty State */}
        {!result && !loading && !error && (
          <div classname="py-20 text-center space-y-6">
            <div classname="inline-flex p-6 bg-slate-900/50 rounded-full border border-slate-800">
              <microscope classname="w-12 h-12 text-slate-700"/>
            </div>
            <div classname="max-w-md mx-auto space-y-2">
              <h3 classname="text-xl font-semibold text-white">Ready for Analysis</h3>
              <p classname="text-slate-500">
                Enter any bacterium, virus, fungus, or parasite to get high-yield clinical and laboratory insights.
              </p>
            </div>
            <div classname="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto pt-4">
              {["S. aureus", "C. difficile", "HIV-1", "C. albicans"].map(ex => (
                <button key="{ex}" onclick="{()" ==""> {
                    setQuery(ex);
                    handleSearch(ex);
                  }}
                  className="p-3 bg-slate-900/30 border border-slate-800 rounded-xl text-xs text-slate-400 hover:border-medical-teal/50 hover:text-medical-teal transition-all"
                >
                  Try "{ex}"
                </button>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
